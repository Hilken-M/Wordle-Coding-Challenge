public class WordleGuessGenerator {
}
